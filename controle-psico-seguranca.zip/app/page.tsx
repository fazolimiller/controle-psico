'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import FormularioEntrega from '@/components/FormularioEntrega';
import TabelaDispensacoes from '@/components/TabelaDispensacoes';
import { Dispensacao, Setor } from '@/lib/types';
import { useSessao, api } from '@/lib/useSessao';
import { hojeLocalISO } from '@/lib/formatarData';

function formatarDataExtenso(dataISO: string): string {
  const [ano, mes, dia] = dataISO.split('-').map(Number);
  const data = new Date(ano, mes - 1, dia);
  return data.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
}

export default function HomePage() {
  const [data, setData] = useState(hojeLocalISO());
  const [dispensacoes, setDispensacoes] = useState<Dispensacao[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [setores, setSetores] = useState<Setor[]>([]);
  const [setoresCarregados, setSetoresCarregados] = useState(false);
  const [setorAtualId, setSetorAtualId] = useState<number | null>(null);
  const [filtroStatus, setFiltroStatus] = useState<'em_posse' | 'devolvida' | 'todas'>('em_posse');
  const router = useRouter();
  const { sessao, isAdmin } = useSessao();

  // Carrega os setores (abas) uma vez, e seleciona o primeiro por padrão
  useEffect(() => {
    api('/api/setores')
      .then((res) => (res.ok ? res.json() : []))
      .then((lista: Setor[]) => {
        setSetores(lista);
        setSetorAtualId((atual) => atual ?? lista[0]?.id ?? null);
        setSetoresCarregados(true);
      })
      .catch(() => setSetoresCarregados(true));
  }, []);

  const carregar = useCallback(async () => {
    if (setorAtualId === null) {
      setCarregando(false);
      setDispensacoes([]);
      return;
    }
    setCarregando(true);
    const params = new URLSearchParams({ data, setorId: String(setorAtualId) });
    if (filtroStatus !== 'todas') {
      params.set('status', filtroStatus);
    }
    const res = await api(`/api/dispensacoes?${params}`);
    if (res.ok) {
      setDispensacoes(await res.json());
    }
    setCarregando(false);
  }, [data, setorAtualId, filtroStatus]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  async function handleLogout() {
    await api('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }

  const pendentes = dispensacoes.filter((d) => d.status === 'em_posse').length;
  const ehHoje = data === hojeLocalISO();
  const setorAtual = setores.find((s) => s.id === setorAtualId) || null;

  return (
    <div className="min-h-screen" style={{ background: 'var(--bg)' }}>
      <header
        className="border-b sticky top-0 z-10"
        style={{ background: 'var(--bg-panel)', borderColor: 'var(--line)' }}
      >
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-3 md:py-4 flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
          <div>
            <h1 className="font-display text-xl" style={{ color: 'var(--ink)' }}>
              Controle de Psicotrópicos
            </h1>
            <p className="text-xs" style={{ color: 'var(--ink-soft)' }}>Farmácia - Santa Casa de São José dos Campos</p>
          </div>
          <nav className="flex flex-wrap items-center gap-1 sm:gap-2">
            <Link
              href="/relatorios"
              className="text-sm font-medium px-3 py-1.5 rounded-lg"
              style={{ color: 'var(--ink)' }}
            >
              Relatórios
            </Link>
            {isAdmin && (
              <Link
                href="/admin"
                className="text-sm font-medium px-3 py-1.5 rounded-lg"
                style={{ color: 'var(--ink)' }}
              >
                Administração
              </Link>
            )}
            {sessao && (
              <Link
                href="/trocar-senha"
                className="text-sm px-3 py-1.5 rounded-lg"
                style={{ color: 'var(--ink-soft)' }}
                title="Trocar minha senha"
              >
                {sessao.nome}
              </Link>
            )}
            <button onClick={handleLogout} className="text-sm px-3 py-1.5 rounded-lg" style={{ color: 'var(--ink-soft)' }}>
              Sair
            </button>
          </nav>
        </div>

        {/* Abas de setor — visíveis para todos os usuários logados */}
        {setores.length > 0 && (
          <div className="max-w-6xl mx-auto px-4 md:px-6 flex gap-1 overflow-x-auto">
            {setores.map((setor) => {
              const ativo = setor.id === setorAtualId;
              return (
                <button
                  key={setor.id}
                  onClick={() => setSetorAtualId(setor.id)}
                  className="px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors"
                  style={
                    ativo
                      ? { borderColor: 'var(--accent)', color: 'var(--accent)' }
                      : { borderColor: 'transparent', color: 'var(--ink-soft)' }
                  }
                >
                  {setor.nome}
                </button>
              );
            })}
          </div>
        )}
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-6 py-6 flex flex-col gap-6">
        {setoresCarregados && setores.length === 0 ? (
          <div
            className="rounded-2xl border p-10 text-center"
            style={{ background: 'var(--bg-panel)', borderColor: 'var(--line)' }}
          >
            <p className="font-display text-lg" style={{ color: 'var(--ink)' }}>
              Nenhum setor cadastrado
            </p>
            <p className="text-sm mt-1" style={{ color: 'var(--ink-soft)' }}>
              {isAdmin
                ? 'Cadastre ao menos um setor em Administração → Setores para começar a registrar dispensações.'
                : 'Peça a um administrador para cadastrar os setores em Administração → Setores.'}
            </p>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-2xl capitalize" style={{ color: 'var(--ink)' }}>
                  {formatarDataExtenso(data)}
                </h2>
                {pendentes > 0 && (
                  <p className="text-sm mt-0.5" style={{ color: 'var(--amber)' }}>
                    {pendentes} {pendentes === 1 ? 'caixa em posse' : 'caixas em posse'} aguardando devolução
                  </p>
                )}
              </div>
              <div className="flex flex-wrap items-end gap-2">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: 'var(--ink-soft)' }}>
                    Caixas
                  </label>
                  <select
                    value={filtroStatus}
                    onChange={(e) => setFiltroStatus(e.target.value as 'em_posse' | 'devolvida' | 'todas')}
                    className="rounded-lg border px-3 py-2 text-sm"
                    style={{ borderColor: 'var(--line)', background: 'var(--bg-panel)' }}
                  >
                    <option value="em_posse">Em posse</option>
                    <option value="devolvida">Devolvidas</option>
                    <option value="todas">Todas</option>
                  </select>
                </div>
                <input
                  type="date"
                  value={data}
                  onChange={(e) => setData(e.target.value)}
                  className="rounded-lg border px-3 py-2 text-sm"
                  style={{ borderColor: 'var(--line)', background: 'var(--bg-panel)' }}
                />
                {!ehHoje && (
                  <button
                    onClick={() => setData(hojeLocalISO())}
                    className="text-sm font-medium px-3 py-2 rounded-lg"
                    style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
                  >
                    Voltar para hoje
                  </button>
                )}
              </div>
            </div>

            {ehHoje && <FormularioEntrega onSucesso={carregar} setorAtual={setorAtual} />}

            {carregando ? (
              <div className="text-center py-12 text-sm" style={{ color: 'var(--ink-soft)' }}>
                Carregando…
              </div>
            ) : (
              <TabelaDispensacoes dispensacoes={dispensacoes} onAtualizar={carregar} isAdmin={isAdmin} />
            )}
          </>
        )}
      </main>
    </div>
  );
}
